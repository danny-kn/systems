#ifndef MAIN_H
#define MAIN_H

void sigint_handler(int sig);
void sigquit_handler(int sig);

#endif
